#define PCI_CONFIG_H
#define PCI_ARCH_AARCH64
#define PCI_OS_LINUX
#define PCI_HAVE_PM_LINUX_SYSFS
#define PCI_HAVE_PM_LINUX_PROC
#define PCI_HAVE_LINUX_BYTEORDER_H
#define PCI_PATH_PROC_BUS_PCI "/proc/bus/pci"
#define PCI_PATH_SYS_BUS_PCI "/sys/bus/pci"
#define PCI_HAVE_64BIT_ADDRESS
#define PCI_HAVE_PM_DUMP
#define PCI_IDS "pci.ids"
#define PCI_PATH_IDS_DIR "/data/data/com.termux/files/usr/share"
#define PCILIB_VERSION "3.1.4"
